package com.rest.api.stub;
import java.time.Instant;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.delete;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.any;
import static com.github.tomakehurst.wiremock.client.WireMock.anyUrl;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;

/**
 * Generate API Stub response for all Employee related operations
 */
public class EmployeeStub {


	protected void stubValidLoginRequest() {
		System.out.println("caleds");
		stubFor(get(urlPathMatching("/employee/login"))
				.willReturn(aResponse()
						.withStatus(200)
						.withHeader("Content-Type", "application/json")
						.withHeader("X-RATE-LIMIT", "10")
						.withHeader("X-EXPIRES-AFTER", String.valueOf(Instant.now().toEpochMilli()))
						.withBodyFile("login_response.json")
						.withBody("{\"message\":\"successful operation\"}")
						));
	}

	protected void stubInvalidLoginRequest() {
		stubFor(get(urlEqualTo("/employee/login"))
				.willReturn(aResponse()
						.withStatus(403)
						.withHeader("Content-Type", "application/json")
						.withBody("{\"message\":\"Bad Credentials\"}")
				));
	}

	protected void stubCreateEmployeeRequest() {
		stubFor(post(urlEqualTo("/employee"))
				.withBasicAuth("ajay@gmail.com", "myPassword")
				.willReturn(aResponse()
						.withStatus(201)
						.withHeader("Content-Type", "application/json")
						.withBodyFile("create-employee.json")
						.withBody("{\"message\":\"successful operation\"}")
				));
	}

	protected void stubCreateEmployeeInvalidRequest() {
		stubFor(post(urlEqualTo("/employee"))
				.withBasicAuth("ajay@gmail.com", "myPasswords")
				.willReturn(aResponse()
						.withStatus(403)
						.withHeader("Content-Type", "application/json")
						.withBody("{\"message\":\"Not Authorised\"}")
				));
	}

	protected void stubUpdateEmployeeRequest() {
		stubFor(put(urlPathMatching("/employee/employeename"))
				.withQueryParam("first_name", matching("([A-Za-z]+)$"))
				.withBasicAuth("ajay@gmail.com", "myPassword")
				.willReturn(aResponse()
						.withStatus(202)
						.withHeader("Content-Type", "application/json")
						.withBodyFile("update-employee.json")
						.withBody("{\"message\":\"successful operation\"}")
				));
	}

	protected void stubInvalidUpdateEmployeeRequest() {
		stubFor(put(urlPathMatching("/employee/employeename"))
				.withQueryParam("first_name", matching("([A-Za-z]+)$"))
				.withBasicAuth("ajay@gmail.com", "myPassword")
				.willReturn(aResponse()
						.withStatus(400)
						.withHeader("Content-Type", "application/json")
						.withBody("{\"message\":\"Emp not found\"}")
				));
	}

	protected void stubDeleteEmployeeRequest(){
		stubFor(delete(urlPathMatching("/employee/employeename"))
				.withQueryParam("first_name", matching("([A-Za-z]+)$"))
				.withBasicAuth("ajay@gmail.com", "myPassword")
				.willReturn(aResponse()
						.withStatus(203)
						.withHeader("Content-Type", "application/json")
						.withBody("{\"message\":\"successful operation\"}")
				));
	}

	protected void stubDeleteInvalidEmployeeRequest(){
		stubFor(delete(urlPathMatching("/employee/employeename"))
				.withQueryParam("first_name", matching("([A-Za-z]+)$"))
				.withBasicAuth("ajay@gmail.com", "myPassword")
				.willReturn(aResponse()
						.withStatus(403)
						.withHeader("Content-Type", "application/json")
						.withBody("{\"message\":\"bad credentials\"}")
				));
	}

	protected void stubGetEmpDetailsRequest() {
		stubFor(get(urlPathMatching("/employee/employeename"))
				.withQueryParam("first_name", matching("([A-Za-z]+)$"))
				.willReturn(aResponse()
						.withStatus(200)
						.withHeader("Content-Type", "application/json")
						.withHeader("X-RATE-LIMIT", "10")
						.withHeader("X-EXPIRES-AFTER", String.valueOf(Instant.now().toEpochMilli()))
						.withBodyFile("employee_details.json")
						.withBody("{\"message\":\"successful operation\"}")
				));
	}

	protected void stubInvalidGetEmpDetailsRequest() {
		stubFor(get(urlPathMatching("/employee/employeename"))
				.withQueryParam("first_name", matching("([A-Za-z]+)$"))
				.willReturn(aResponse()
						.withStatus(404)
						.withHeader("Content-Type", "application/json")
						.withBody("{\"message\":\"user not found\"}")
				));
	}


	protected void stubLogoutRequest() {
		stubFor(get(urlEqualTo("/employee/logout"))
				.willReturn(aResponse()
						.withStatus(200)
						.withHeader("Content-Type", "application/json")
						.withBodyFile("login_response.json")
						.withBody("{\"message\":\"successful operation\"}")
						));
	}


	protected void stubDefaultRouteNotFound(){
		stubFor(any(anyUrl())
				.atPriority(10)
				.willReturn(aResponse()
						.withStatus(404)
						.withBody("{\"message\":\"url not found\"}")
						));
	}

}


