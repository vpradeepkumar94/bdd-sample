package com.rest.api.conf;

public final class Scenarios {
    
    public static final String VALID_LOGIN_SCENARIO = "Valid Login Request";

    public static final String INVALID_LOGIN_REQUEST_SCENARIO = "Invalid Login Request";
    
    public static final String CREATE_NEW_EMPLOYEE_SCENARIO = "Create Employee";

    public static final String NEW_EMPLOYEE_CREATION_FAILURE_SCENARIO = "Create Employee With Invalid Details";

    public static final String BULK_UPLOAD_EMPLOYEES_SCENARIO = "Create Employees";
    
    public static final String UPDATE_EMPLOYEE_DETAILS_SCENARIO = "Update Employee Details";

    public static final String UPDATE_EMPLOYEE_DETAILS_FAILURE_SCENARIO = "Update Employee Details with Invalid Details";

    public static final String GET_EMPLOYEE_DETAILS_SCENARIO = "Get Employee Details";

    public static final String GET_EMPLOYEE_DETAILS_FAILURE_SCENARIO = "Get Employee Details With Invalid Details";

    public static final String DELETE_EMPLOYEE_SCENARIO = "Delete Employee";

    public static final String DELETE_EMPLOYEE_FAILURE_SCENARIO = "Delete Employee Invalid Request";

    public static final String LOGOUT_SCENARIO = "Logout API";
}
