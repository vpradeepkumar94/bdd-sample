package com.rest.api.steps;

import com.rest.api.SpringIntegrationTest;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

import static org.hamcrest.CoreMatchers.containsString;

import org.junit.Assert;
import org.junit.Ignore;
import org.springframework.beans.factory.annotation.Value;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsInAnyOrder;

import java.util.List;

@Ignore
public class EmployeeSteps extends SpringIntegrationTest {


	@Value("${app.employees.uri}")
	protected String baseURI;
	
	protected static RequestSpecification request;
	protected static Response response;
	protected static ValidatableResponse json;
	protected static RestAssuredConfig config;

	@Given("^service request timeout is set$")
	public void configureServiceTimeout() {
		config = RestAssured.config().httpClient(HttpClientConfig.httpClientConfig()
									 .setParam("http.connection.timeout", timeOut)
						             .setParam("http.socket.timeout", timeOut)
						             .setParam("http.connection-manager.timeout", timeOut))
				.sslConfig(new SSLConfig().allowAllHostnames());
	}

	@Given("^the username is (.*) and password is (.*)$")
	public void credentials(String username, String password) {
		request = given()
				.log()
				.all()
				.baseUri(baseURI)
				.config(config)
				.auth()
				.basic(username, password);
	}

	@When("^I make a get request$")
	public void getLogin() {
		response = request
				.when()
				.get("employee/login");
	}

	@Then("^the api returns a status code of (\\d+)$")
	public void service_code_check(int statusCode) {
		json = response
				.then()
				.statusCode(statusCode);
	}

	@Then("^the response has (.*)$")
	public void response_check(String expectedText) {
		response
				.then()
				.assertThat()
				.body("message", containsString(expectedText));
	}

	@And("^the following response headers are returned$")
	public void theFollowingResponseHeadersAreReturned(List<String> headers) {
		Headers httpHeaders = response.headers();
		headers.forEach(header -> {
			Assert.assertTrue(httpHeaders.hasHeaderWithName(header));
		});
	}

	@Given("^the employee first name as (.*)$")
	public void add_first_name(String firstName) {
		request = request.log().all().param("first_name", firstName);
	}
	
	
	@Given("^the employee last name as (.*)$")
	public void add_last_name(String lastName) {
		request = request.formParam("last_name", lastName);
	}
	
	@Given("^the employee email as (.*)$")
	public void add_email(String email) {
		request = request.formParam("email", email);
	}

	@When("^the client makes a Post Request$")
	public void create_employee() {
		response = request.log().all().post("employee");
	}

	@Given("^the employee names as list")
	public void empArray(List<String> data) {
		request = request.formParam("Emplist", data);
	}

	@When("^the client create an employee records as list")
	public void postEmpArray() {
		request.post("employee");
	}

	@Given("^the employee first name (.*) to search")
	public void searchbyfirstnamee(String data) {
		request = given().log().all().baseUri(baseURI).param("first_name", data);
	}
	
	@When("the client get employee by employee name")
	public void getemployeeByName() {
		response = request.get("employee/employeename");
	}

	@Given("the employee name (.*) of the employee to be updated")
	public void empNameUpdate(String data) {
		request = request.queryParam("first_name", data);
	}

	@When("the client makes Put request")
	public void putEmp() {
		response = request.put("employee/employeename");
	}

	@Given("^the user logged in with (.*) and (.*)")
	public void authenticateuser(String userName, String password) {
		request = given().log().all().baseUri(baseURI).config(config).auth().preemptive().basic(userName, password);
	}

	@Given("the (.*) of the employee to be deleted")
	public void empNameDelete(String data) {
		request = request.queryParam("first_name", data);
	}

	@When("the client makes a DELETE request")
	public void deleteEmp() {
		response = request.delete("employee/employeename");
	}

	@Given("^the user logs out from the system$")
	public void logoutsystem() {
		request = given().log().all().baseUri(baseURI).config(config);
	}

	@When("^the client makes Get Request to /logout$")
	public void getLogout() {
		response = request.get("employee/logout");
	}

}
