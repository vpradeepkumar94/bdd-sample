package com.rest.api.hooks;

import com.rest.api.conf.Scenarios;
import com.rest.api.stub.EmployeeStub;
import cucumber.api.Scenario;
import cucumber.api.java.Before;

/**
 * setup method is triggered before running every scenario which sets up Stubs
 */
public class Hooks extends EmployeeStub {
	
	@Before
	public void setUp(Scenario scenario) {
		initWiremockStub(scenario.getName());
	}

	private void initWiremockStub(String scenarioName) {
		switch (scenarioName) {
			case Scenarios.VALID_LOGIN_SCENARIO:
				stubValidLoginRequest();
				break;
			case Scenarios.INVALID_LOGIN_REQUEST_SCENARIO:
				stubInvalidLoginRequest();
				break;
			case Scenarios.CREATE_NEW_EMPLOYEE_SCENARIO:
				stubCreateEmployeeRequest();
				break;
			case Scenarios.NEW_EMPLOYEE_CREATION_FAILURE_SCENARIO:
				stubCreateEmployeeInvalidRequest();
				break;
			case Scenarios.BULK_UPLOAD_EMPLOYEES_SCENARIO:
				stubCreateEmployeeRequest();
				break;
			case Scenarios.UPDATE_EMPLOYEE_DETAILS_SCENARIO:
				stubUpdateEmployeeRequest();
				break;
			case Scenarios.UPDATE_EMPLOYEE_DETAILS_FAILURE_SCENARIO:
				stubInvalidUpdateEmployeeRequest();
				break;
			case Scenarios.GET_EMPLOYEE_DETAILS_SCENARIO:
				stubGetEmpDetailsRequest();
				break;
			case Scenarios.GET_EMPLOYEE_DETAILS_FAILURE_SCENARIO:
				stubInvalidGetEmpDetailsRequest();
				break;
			case Scenarios.DELETE_EMPLOYEE_SCENARIO:
				stubDeleteEmployeeRequest();
				break;
			case Scenarios.DELETE_EMPLOYEE_FAILURE_SCENARIO:
				stubDeleteInvalidEmployeeRequest();
				break;
			case Scenarios.LOGOUT_SCENARIO:
				stubLogoutRequest();
				break;
			default:
				System.out.println("breaking for scenario" + scenarioName);
				break;
		}
	}

}