package com.rest.api;


import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(
        glue = {"com.rest.api.steps","com.rest.api.hooks"},
        features = {"src/test/java/com/rest/api/features"},
        plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/reports/report.html"})

public class CucumberRunnerTests extends SpringIntegrationTest{
}
