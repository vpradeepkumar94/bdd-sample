package com.rest.demo.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class IndexController {

	@RequestMapping("/")
	public String hello() {
		return "Hello all API tests were successful";
	}

	@RequestMapping(path="{app_name}")
	public String app(@PathVariable("app_name") String appName) {
		return "Hello all API tests were successful " + appName;
	}

}
