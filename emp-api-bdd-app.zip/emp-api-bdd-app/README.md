# API - BDD Tests  

## Pre-Requisites
1. Java Installed on the machine
2. Maven Installed & env variable configured [Installation guide](https://howtodoinjava.com/maven/how-to-install-maven-on-windows/)

# Local Setup 
1. Clone the repository
2. Run `mvn clean package`

# Start SpringBoot Application
3. Navigate to `target` directory  (if the Test fails, you will not see this directory)
4. Run the command `java -jar springboot-rest-api-bdd-1.0.1.jar`
5. Navigate to `http://localhost:8080` to view server is up

